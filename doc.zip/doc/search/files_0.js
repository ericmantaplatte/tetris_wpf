var searchData=
[
  ['app_2examl_2ecs_0',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['assemblyinfo_2ecs_1',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
