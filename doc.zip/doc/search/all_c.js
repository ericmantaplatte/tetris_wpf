var searchData=
[
  ['sblock_0',['SBlock',['../class_tetris1_1_1_s_block.html',1,'Tetris1']]],
  ['sblock_2ecs_1',['SBlock.cs',['../_s_block_8cs.html',1,'']]],
  ['score_2',['Score',['../class_tetris1_1_1_game_state.html#abdeff0bb4b431cf03641688a7646c24c',1,'Tetris1::GameState']]],
  ['startoffset_3',['startoffset',['../class_tetris1_1_1_block.html#a3d21fa051829c9b16a49adfba5c60e05',1,'Tetris1.Block.StartOffset'],['../class_tetris1_1_1_i_block.html#ac8bc5fb3b8d19638eb41bb2f0876e19a',1,'Tetris1.IBlock.StartOffset'],['../class_tetris1_1_1_j_block.html#a3516592e18c8702b5c438b112378a833',1,'Tetris1.JBlock.StartOffset'],['../class_tetris1_1_1_l_block.html#a904a2af6d865b1796cd250ae8e761a68',1,'Tetris1.LBlock.StartOffset'],['../class_tetris1_1_1_o_block.html#a5c6a57683062eef02fa1e5a60fe6dd0f',1,'Tetris1.OBlock.StartOffset'],['../class_tetris1_1_1_s_block.html#ab9b710400caa2912651799f823a0d5e3',1,'Tetris1.SBlock.StartOffset'],['../class_tetris1_1_1_t_block.html#aa1edfa522e56e02a530471f0947db0f9',1,'Tetris1.TBlock.StartOffset'],['../class_tetris1_1_1_z_block.html#a9cb3d2a39f3584a143884969eced2b3d',1,'Tetris1.ZBlock.StartOffset']]]
];
