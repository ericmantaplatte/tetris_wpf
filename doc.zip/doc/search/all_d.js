var searchData=
[
  ['tblock_0',['TBlock',['../class_tetris1_1_1_t_block.html',1,'Tetris1']]],
  ['tblock_2ecs_1',['TBlock.cs',['../_t_block_8cs.html',1,'']]],
  ['tetris1_2',['Tetris1',['../namespace_tetris1.html',1,'']]],
  ['this_5bint_20r_2c_20int_20c_5d_3',['this[int r, int c]',['../class_tetris1_1_1_game_grid.html#ace239b35f82daa36a4babf989dccc051',1,'Tetris1::GameGrid']]],
  ['tilepositions_4',['TilePositions',['../class_tetris1_1_1_block.html#ad1d898065f8ebb0d7b8f27639f8a04eb',1,'Tetris1::Block']]],
  ['tiles_5',['tiles',['../class_tetris1_1_1_block.html#ae22280754f87027ba12b4de2e118d0b9',1,'Tetris1.Block.Tiles'],['../class_tetris1_1_1_i_block.html#a327bbb5955764464c6cf8b1bea9f7902',1,'Tetris1.IBlock.Tiles'],['../class_tetris1_1_1_j_block.html#a1bc48c56e4cbe4688ea1108b1f1180b9',1,'Tetris1.JBlock.Tiles'],['../class_tetris1_1_1_l_block.html#a6edd54191047cd166763db36d33cacac',1,'Tetris1.LBlock.Tiles'],['../class_tetris1_1_1_o_block.html#ad5f90d94d6f59135f2718d49ac872b3a',1,'Tetris1.OBlock.Tiles'],['../class_tetris1_1_1_s_block.html#a1919378bb65ac9e05c4bccdf8dce2c5c',1,'Tetris1.SBlock.Tiles'],['../class_tetris1_1_1_t_block.html#a067c9df6591a406e1ec3432e9a650570',1,'Tetris1.TBlock.Tiles'],['../class_tetris1_1_1_z_block.html#ae06e100c64bb6cc13199c39c12c8b466',1,'Tetris1.ZBlock.Tiles']]]
];
