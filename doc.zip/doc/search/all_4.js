var searchData=
[
  ['iblock_0',['IBlock',['../class_tetris1_1_1_i_block.html',1,'Tetris1']]],
  ['iblock_2ecs_1',['IBlock.cs',['../_i_block_8cs.html',1,'']]],
  ['id_2',['id',['../class_tetris1_1_1_block.html#a89b1dd469d27d912396c23ef9c370f96',1,'Tetris1.Block.Id'],['../class_tetris1_1_1_i_block.html#a57c7c0940f03b56f9deb39098cd2dc66',1,'Tetris1.IBlock.Id'],['../class_tetris1_1_1_j_block.html#a842801448d3040fa3119bebcd39b1d42',1,'Tetris1.JBlock.Id'],['../class_tetris1_1_1_l_block.html#ac612ba11210b5abdddf8f227ad5e4668',1,'Tetris1.LBlock.Id'],['../class_tetris1_1_1_o_block.html#ab447d219f6631172383656840dfb51af',1,'Tetris1.OBlock.Id'],['../class_tetris1_1_1_s_block.html#ae48f557808f55fcff560501328dc118d',1,'Tetris1.SBlock.Id'],['../class_tetris1_1_1_t_block.html#abda4f17bc2b47aeb10453987d9a562a7',1,'Tetris1.TBlock.Id'],['../class_tetris1_1_1_z_block.html#aac15330ab9aad6a4c3a03395095183ff',1,'Tetris1.ZBlock.Id']]],
  ['isempty_3',['IsEmpty',['../class_tetris1_1_1_game_grid.html#a5a4d6f488f670f707fc3714253c754e7',1,'Tetris1::GameGrid']]],
  ['isinside_4',['isInside',['../class_tetris1_1_1_game_grid.html#a725586be1ac04bd288ab1da4df7fd869',1,'Tetris1::GameGrid']]],
  ['isrowempty_5',['isRowEmpty',['../class_tetris1_1_1_game_grid.html#a1b42b4a05226ceb39f5b3fcb5ddc606a',1,'Tetris1::GameGrid']]],
  ['isrowfull_6',['isRowFull',['../class_tetris1_1_1_game_grid.html#a0a0c011366a8c878a430d6589c9d6463',1,'Tetris1::GameGrid']]]
];
