var searchData=
[
  ['app_0',['App',['../class_tetris1_1_1_app.html',1,'Tetris1']]],
  ['app_2examl_2ecs_1',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['assemblyinfo_2ecs_2',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
