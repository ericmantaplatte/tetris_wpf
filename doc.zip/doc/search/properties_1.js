var searchData=
[
  ['gamegrid_0',['GameGrid',['../class_tetris1_1_1_game_state.html#a13cad419e3cb22c1fd4faf9297e98eee',1,'Tetris1::GameState']]],
  ['gameover_1',['GameOver',['../class_tetris1_1_1_game_state.html#ac605627c5c42f3079928cc2429c510f7',1,'Tetris1::GameState']]]
];
