var searchData=
[
  ['mainwindow_0',['MainWindow',['../class_tetris1_1_1_main_window.html',1,'Tetris1']]]
];
