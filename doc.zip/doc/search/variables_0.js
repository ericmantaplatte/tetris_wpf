var searchData=
[
  ['gamespeed_0',['gameSpeed',['../class_tetris1_1_1_game_state.html#af0498ebcc93b33a2dfd2d00d05fd851b',1,'Tetris1::GameState']]]
];
