var class_tetris1_1_1_l_block =
[
    [ "Id", "class_tetris1_1_1_l_block.html#ac612ba11210b5abdddf8f227ad5e4668", null ],
    [ "StartOffset", "class_tetris1_1_1_l_block.html#a904a2af6d865b1796cd250ae8e761a68", null ],
    [ "Tiles", "class_tetris1_1_1_l_block.html#a6edd54191047cd166763db36d33cacac", null ]
];