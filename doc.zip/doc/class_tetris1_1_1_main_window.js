var class_tetris1_1_1_main_window =
[
    [ "MainWindow", "class_tetris1_1_1_main_window.html#afae125fe343b08545ac32d5e1687722f", null ]
];