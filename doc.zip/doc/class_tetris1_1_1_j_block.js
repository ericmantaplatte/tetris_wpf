var class_tetris1_1_1_j_block =
[
    [ "Id", "class_tetris1_1_1_j_block.html#a842801448d3040fa3119bebcd39b1d42", null ],
    [ "StartOffset", "class_tetris1_1_1_j_block.html#a3516592e18c8702b5c438b112378a833", null ],
    [ "Tiles", "class_tetris1_1_1_j_block.html#a1bc48c56e4cbe4688ea1108b1f1180b9", null ]
];