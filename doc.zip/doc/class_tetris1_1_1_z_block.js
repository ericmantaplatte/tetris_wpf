var class_tetris1_1_1_z_block =
[
    [ "Id", "class_tetris1_1_1_z_block.html#aac15330ab9aad6a4c3a03395095183ff", null ],
    [ "StartOffset", "class_tetris1_1_1_z_block.html#a9cb3d2a39f3584a143884969eced2b3d", null ],
    [ "Tiles", "class_tetris1_1_1_z_block.html#ae06e100c64bb6cc13199c39c12c8b466", null ]
];