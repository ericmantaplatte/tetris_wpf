var class_tetris1_1_1_i_block =
[
    [ "Id", "class_tetris1_1_1_i_block.html#a57c7c0940f03b56f9deb39098cd2dc66", null ],
    [ "StartOffset", "class_tetris1_1_1_i_block.html#ac8bc5fb3b8d19638eb41bb2f0876e19a", null ],
    [ "Tiles", "class_tetris1_1_1_i_block.html#a327bbb5955764464c6cf8b1bea9f7902", null ]
];