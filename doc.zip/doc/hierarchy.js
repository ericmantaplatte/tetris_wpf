var hierarchy =
[
    [ "Application", null, [
      [ "Tetris1.App", "class_tetris1_1_1_app.html", null ]
    ] ],
    [ "Tetris1.Block", "class_tetris1_1_1_block.html", [
      [ "Tetris1.IBlock", "class_tetris1_1_1_i_block.html", null ],
      [ "Tetris1.JBlock", "class_tetris1_1_1_j_block.html", null ],
      [ "Tetris1.LBlock", "class_tetris1_1_1_l_block.html", null ],
      [ "Tetris1.OBlock", "class_tetris1_1_1_o_block.html", null ],
      [ "Tetris1.SBlock", "class_tetris1_1_1_s_block.html", null ],
      [ "Tetris1.TBlock", "class_tetris1_1_1_t_block.html", null ],
      [ "Tetris1.ZBlock", "class_tetris1_1_1_z_block.html", null ]
    ] ],
    [ "Tetris1.BlockPosition", "class_tetris1_1_1_block_position.html", null ],
    [ "Tetris1.BlockQueue", "class_tetris1_1_1_block_queue.html", null ],
    [ "Tetris1.GameGrid", "class_tetris1_1_1_game_grid.html", null ],
    [ "Tetris1.GameState", "class_tetris1_1_1_game_state.html", null ],
    [ "Window", null, [
      [ "Tetris1.MainWindow", "class_tetris1_1_1_main_window.html", null ]
    ] ]
];