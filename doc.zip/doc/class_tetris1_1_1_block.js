var class_tetris1_1_1_block =
[
    [ "Block", "class_tetris1_1_1_block.html#a8f66aab4c9f34b20a8cc049d9dab530f", null ],
    [ "Move", "class_tetris1_1_1_block.html#ab161bff6de27d89d35e34a982370d2b3", null ],
    [ "Reset", "class_tetris1_1_1_block.html#affed05e88f4a6af0161dac99b5fbf0fb", null ],
    [ "RotateClockWise", "class_tetris1_1_1_block.html#a0c71f914489960f84b998da3dfeaba4f", null ],
    [ "RotatteCounterClockWise", "class_tetris1_1_1_block.html#ae0e1fe3e699a0e6b9f1e7cb6c96d0b06", null ],
    [ "TilePositions", "class_tetris1_1_1_block.html#ad1d898065f8ebb0d7b8f27639f8a04eb", null ],
    [ "Id", "class_tetris1_1_1_block.html#a89b1dd469d27d912396c23ef9c370f96", null ],
    [ "StartOffset", "class_tetris1_1_1_block.html#a3d21fa051829c9b16a49adfba5c60e05", null ],
    [ "Tiles", "class_tetris1_1_1_block.html#ae22280754f87027ba12b4de2e118d0b9", null ]
];