var class_tetris1_1_1_t_block =
[
    [ "Id", "class_tetris1_1_1_t_block.html#abda4f17bc2b47aeb10453987d9a562a7", null ],
    [ "StartOffset", "class_tetris1_1_1_t_block.html#aa1edfa522e56e02a530471f0947db0f9", null ],
    [ "Tiles", "class_tetris1_1_1_t_block.html#a067c9df6591a406e1ec3432e9a650570", null ]
];