var class_tetris1_1_1_s_block =
[
    [ "Id", "class_tetris1_1_1_s_block.html#ae48f557808f55fcff560501328dc118d", null ],
    [ "StartOffset", "class_tetris1_1_1_s_block.html#ab9b710400caa2912651799f823a0d5e3", null ],
    [ "Tiles", "class_tetris1_1_1_s_block.html#a1919378bb65ac9e05c4bccdf8dce2c5c", null ]
];