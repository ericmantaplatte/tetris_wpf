var files_dup =
[
    [ "App.xaml.cs", "_app_8xaml_8cs.html", "_app_8xaml_8cs" ],
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "Block.cs", "_block_8cs.html", "_block_8cs" ],
    [ "BlockPosition.cs", "_block_position_8cs.html", "_block_position_8cs" ],
    [ "BlockQueue.cs", "_block_queue_8cs.html", "_block_queue_8cs" ],
    [ "GameGrid.cs", "_game_grid_8cs.html", "_game_grid_8cs" ],
    [ "GameState.cs", "_game_state_8cs.html", "_game_state_8cs" ],
    [ "IBlock.cs", "_i_block_8cs.html", "_i_block_8cs" ],
    [ "JBlock.cs", "_j_block_8cs.html", "_j_block_8cs" ],
    [ "LBlock.cs", "_l_block_8cs.html", "_l_block_8cs" ],
    [ "MainWindow.xaml.cs", "_main_window_8xaml_8cs.html", "_main_window_8xaml_8cs" ],
    [ "OBlock.cs", "_o_block_8cs.html", "_o_block_8cs" ],
    [ "SBlock.cs", "_s_block_8cs.html", "_s_block_8cs" ],
    [ "TBlock.cs", "_t_block_8cs.html", "_t_block_8cs" ],
    [ "ZBlock.cs", "_z_block_8cs.html", "_z_block_8cs" ]
];