var class_tetris1_1_1_o_block =
[
    [ "Id", "class_tetris1_1_1_o_block.html#ab447d219f6631172383656840dfb51af", null ],
    [ "StartOffset", "class_tetris1_1_1_o_block.html#a5c6a57683062eef02fa1e5a60fe6dd0f", null ],
    [ "Tiles", "class_tetris1_1_1_o_block.html#ad5f90d94d6f59135f2718d49ac872b3a", null ]
];