var namespaces_dup =
[
    [ "Tetris1", "namespace_tetris1.html", "namespace_tetris1" ]
];